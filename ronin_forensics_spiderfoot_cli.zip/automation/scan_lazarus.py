import subprocess

print("📡 Running Lazarus scan using SpiderFoot CLI...")

try:
    subprocess.run([
        "python3", "/opt/spiderfoot/sf.py",
        "-s", "ronin.network",
        "-o", "csv",
        "-m", "ip,domain,whois"
    ], check=True)
except subprocess.CalledProcessError as e:
    print(f"❌ SpiderFoot scan failed: {e}")
